<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* agence_immobiliere/biens_immobiliers.html.twig */
class __TwigTemplate_109dbda92bfdf9a6003a17eeb5d3cdd02088233697f75a01488f6a9f819a71d8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence_immobiliere/biens_immobiliers.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence_immobiliere/biens_immobiliers.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "agence_immobiliere/biens_immobiliers.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "E221 Tech.com | Nos biens immobiliers";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1 class=\"text-center\">Nos biens </h1>
<hr>

<div class=\"container\">
";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["biens_immo"]) || array_key_exists("biens_immo", $context) ? $context["biens_immo"] : (function () { throw new RuntimeError('Variable "biens_immo" does not exist.', 10, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["bien_immo"]) {
            // line 11
            echo "<p>Type d'habitation: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bien_immo"], "type", [], "any", false, false, false, 11), "html", null, true);
            echo "</p>
<p>Surface: ";
            // line 12
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bien_immo"], "surface", [], "any", false, false, false, 12), "html", null, true);
            echo " m²</p>
<p>Prix: ";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bien_immo"], "prix", [], "any", false, false, false, 13), "html", null, true);
            echo " €</p>
<p>localisation: ";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bien_immo"], "localisation", [], "any", false, false, false, 14), "html", null, true);
            echo "</p>
<img src=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("images/biens/" . twig_get_attribute($this->env, $this->source, $context["bien_immo"], "images", [], "any", false, false, false, 15))), "html", null, true);
            echo "\" width=\"200\" alt=\"\">
<p>Date de mise en ligne: ";
            // line 16
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bien_immo"], "dateDeCreation", [], "any", false, false, false, 16), "d/m/Y à H:i"), "html", null, true);
            echo "</p>
<hr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bien_immo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "
<h2 class=\"text-center\">Ajouter un nouveau bien</h2>

";
        // line 22
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 22, $this->source); })()), 'form_start');
        echo "
";
        // line 23
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 23, $this->source); })()), "type", [], "any", false, false, false, 23), 'row', ["label" => "Entrez un type d'habitation:"]);
        echo "
";
        // line 24
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 24, $this->source); })()), "surface", [], "any", false, false, false, 24), 'row', ["label" => "Entrez une surface (en m²):"]);
        echo "
";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 25, $this->source); })()), "prix", [], "any", false, false, false, 25), 'row', ["label" => "Entrez le prix du bien (en €):"]);
        echo "
";
        // line 26
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 26, $this->source); })()), "localisation", [], "any", false, false, false, 26), 'row', ["label" => "Entrez une localisation:"]);
        echo "
";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 27, $this->source); })()), "images", [], "any", false, false, false, 27), 'row', ["label" => "Insérez une image:"]);
        echo "
<button type=\"submit\" class=\"btn btn-success\">Ajouter</button>
";
        // line 29
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form_biens"]) || array_key_exists("form_biens", $context) ? $context["form_biens"] : (function () { throw new RuntimeError('Variable "form_biens" does not exist.', 29, $this->source); })()), 'form_end');
        echo "
<br>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "agence_immobiliere/biens_immobiliers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 29,  153 => 27,  149 => 26,  145 => 25,  141 => 24,  137 => 23,  133 => 22,  128 => 19,  119 => 16,  115 => 15,  111 => 14,  107 => 13,  103 => 12,  98 => 11,  94 => 10,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}E221 Tech.com | Nos biens immobiliers{% endblock %}

{% block body %}
<h1 class=\"text-center\">Nos biens </h1>
<hr>

<div class=\"container\">
{% for bien_immo in biens_immo %}
<p>Type d'habitation: {{ bien_immo.type }}</p>
<p>Surface: {{ bien_immo.surface }} m²</p>
<p>Prix: {{ bien_immo.prix }} €</p>
<p>localisation: {{ bien_immo.localisation }}</p>
<img src=\"{{ asset('images/biens/' ~ bien_immo.images) }}\" width=\"200\" alt=\"\">
<p>Date de mise en ligne: {{ bien_immo.dateDeCreation | date(\"d/m/Y à H:i\") }}</p>
<hr>
{% endfor %}

<h2 class=\"text-center\">Ajouter un nouveau bien</h2>

{{ form_start(form_biens) }}
{{ form_row(form_biens.type,  {\"label\": \"Entrez un type d'habitation:\"}) }}
{{ form_row(form_biens.surface,  {\"label\": \"Entrez une surface (en m²):\"}) }}
{{ form_row(form_biens.prix,  {\"label\": \"Entrez le prix du bien (en €):\"}) }}
{{ form_row(form_biens.localisation,  {\"label\": \"Entrez une localisation:\"}) }}
{{ form_row(form_biens.images,  {\"label\": \"Insérez une image:\"}) }}
<button type=\"submit\" class=\"btn btn-success\">Ajouter</button>
{{ form_end(form_biens) }}
<br>
</div>
{% endblock %}
", "agence_immobiliere/biens_immobiliers.html.twig", "C:\\Users\\khidma\\Desktop\\COURS\\BON SYMFONY\\BON 1\\templates\\agence_immobiliere\\biens_immobiliers.html.twig");
    }
}
