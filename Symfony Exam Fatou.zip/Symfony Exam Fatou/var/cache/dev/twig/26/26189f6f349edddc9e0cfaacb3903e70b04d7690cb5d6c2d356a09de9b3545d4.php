<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* agence_immobiliere/authentification.html.twig */
class __TwigTemplate_64873d57c68ee2b27c131752ab2c8b02a353846ef234431f3c29edfaa28eb530 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence_immobiliere/authentification.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence_immobiliere/authentification.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "agence_immobiliere/authentification.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Immobilier.com | Authentification";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<br>
<div class=\"container\">
<div class=\"row\">
<div class=\"col-md-6\">
    <h1 class=\"text-center\">Connexion </h1>
    <hr>
<h3>Veuillez vous connecter !</h3>
<form action=\" ";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
        echo "\" method=\"post\">

    ";
        // line 15
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 15, $this->source); })())) {
            // line 16
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 16, $this->source); })()), "messageKey", [], "any", false, false, false, 16), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 16, $this->source); })()), "messageData", [], "any", false, false, false, 16), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 18
        echo "
    ";
        // line 19
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19)) {
            // line 20
            echo "        <div class=\"mb-3\">
            You are logged in as ";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 21, $this->source); })()), "user", [], "any", false, false, false, 21), "username", [], "any", false, false, false, 21), "html", null, true);
            echo ", <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Logout</a>
        </div>
    ";
        }
        // line 24
        echo "
    <div class=\"form-group\">
        <input type=\"email\" name=\"email\" placeholder=\"Identifiant\" class=\"form-control\" >
    </div>
    
    <div class=\"form-group\">
        <input type=\"password\" name=\"password\" placeholder=\"Mot de passe\" class=\"form-control\"  >
    </div>
    <input type=\"hidden\" name=\"_csrf_token\"
           value=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"
    >
<button class=\"btn btn-success\" class=\"form-control\">Se connecter</button>
</form>
</div>

<div class=\"col-md-6\">
    <h1 class=\"text-center\">Inscription </h1>
    <hr>
<h3>Veuillez vous inscrire !</h3>
";
        // line 43
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 43, $this->source); })()), 'form_start');
        echo "
";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 44, $this->source); })()), "nom", [], "any", false, false, false, 44), 'row', ["label" => "Entrez un nom :"]);
        echo "
";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 45, $this->source); })()), "prenom", [], "any", false, false, false, 45), 'row', ["label" => "Entrez un prénom :"]);
        echo "
";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 46, $this->source); })()), "email", [], "any", false, false, false, 46), 'row', ["label" => "Entrez un email :"]);
        echo "
";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 47, $this->source); })()), "mot_de_passe", [], "any", false, false, false, 47), 'row', ["label" => "Entrez un mot de passe :"]);
        echo "
";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 48, $this->source); })()), "confirm_mot_de_passe", [], "any", false, false, false, 48), 'row', ["label" => "Confirmez le mot de passe :"]);
        echo "
";
        // line 49
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 49, $this->source); })()), "localisation", [], "any", false, false, false, 49), 'row', ["label" => "Entrez une ville :"]);
        echo "
<br>
<button type=\"submit\" class=\"btn btn-success\">S'inscrire</button>
";
        // line 52
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form_inscription"]) || array_key_exists("form_inscription", $context) ? $context["form_inscription"] : (function () { throw new RuntimeError('Variable "form_inscription" does not exist.', 52, $this->source); })()), 'form_end');
        echo "
</div>
</div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "agence_immobiliere/authentification.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 52,  174 => 49,  170 => 48,  166 => 47,  162 => 46,  158 => 45,  154 => 44,  150 => 43,  137 => 33,  126 => 24,  118 => 21,  115 => 20,  113 => 19,  110 => 18,  104 => 16,  102 => 15,  97 => 13,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Immobilier.com | Authentification{% endblock %}

{% block body %}
<br>
<div class=\"container\">
<div class=\"row\">
<div class=\"col-md-6\">
    <h1 class=\"text-center\">Connexion </h1>
    <hr>
<h3>Veuillez vous connecter !</h3>
<form action=\" {{ path('app_login')}}\" method=\"post\">

    {% if error %}
        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
    {% endif %}

    {% if app.user %}
        <div class=\"mb-3\">
            You are logged in as {{ app.user.username }}, <a href=\"{{ path('app_logout') }}\">Logout</a>
        </div>
    {% endif %}

    <div class=\"form-group\">
        <input type=\"email\" name=\"email\" placeholder=\"Identifiant\" class=\"form-control\" >
    </div>
    
    <div class=\"form-group\">
        <input type=\"password\" name=\"password\" placeholder=\"Mot de passe\" class=\"form-control\"  >
    </div>
    <input type=\"hidden\" name=\"_csrf_token\"
           value=\"{{ csrf_token('authenticate') }}\"
    >
<button class=\"btn btn-success\" class=\"form-control\">Se connecter</button>
</form>
</div>

<div class=\"col-md-6\">
    <h1 class=\"text-center\">Inscription </h1>
    <hr>
<h3>Veuillez vous inscrire !</h3>
{{ form_start(form_inscription) }}
{{ form_row(form_inscription.nom,  {\"label\": \"Entrez un nom :\"}) }}
{{ form_row(form_inscription.prenom,  {\"label\": \"Entrez un prénom :\"}) }}
{{ form_row(form_inscription.email,  {\"label\": \"Entrez un email :\"}) }}
{{ form_row(form_inscription.mot_de_passe, {\"label\": \"Entrez un mot de passe :\"}) }}
{{ form_row(form_inscription.confirm_mot_de_passe,  {\"label\": \"Confirmez le mot de passe :\"}) }}
{{ form_row(form_inscription.localisation, {\"label\": \"Entrez une ville :\"}) }}
<br>
<button type=\"submit\" class=\"btn btn-success\">S'inscrire</button>
{{ form_end(form_inscription) }}
</div>
</div>
</div>
{% endblock %}
", "agence_immobiliere/authentification.html.twig", "C:\\Users\\khidma\\Desktop\\COURS\\BON SYMFONY\\BON 1\\templates\\agence_immobiliere\\authentification.html.twig");
    }
}
